public class AuthorizationLevels
{
    private int _authorizationLevelID;
    private String _levelName;
    private int _levelValue;

    public int getAuthorizationLevelID()
    {
        return _authorizationLevelID;
    }
    public String getLevelName()
    {
        return _levelName;
    }
    public int getLevelValue()
    {
        return _levelValue;
    }
}
