public class ProductImageModel {
    private byte[] _product_Image;

    private byte[] _product_Detail_Image;

    public byte[] get_product_Image() {
        return _product_Image;
    }

    public void set_product_Image(byte[] _product_Image) {
        this._product_Image = _product_Image;
    }

    public byte[] get_product_Detail_Image() {
        return _product_Detail_Image;
    }

    public void set_product_Detail_Image(byte[] _product_Detail_Image) {
        this._product_Detail_Image = _product_Detail_Image;
    }




}
