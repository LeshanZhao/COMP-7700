public class WebProductDetailView {

    public static String getHTMLString_ForProductDetailPage(Product product_toViewDetail) {
        String response =  "<html><body>";

        response += "<h1>Welcome to the Online Shopping Website!</h1>";

        response += "<button onclick=\"history.back()\">Go Back</button> &emsp;&emsp;&emsp;";

        response += "Your are looking at product that you selected: </br>";
        response += "<b>Product Name:</b> <span style=\"color: blue;\">" + product_toViewDetail.getProductName() + "</span></br>";

        String img_name = "imgs/broom1Detail.jpg";
        if (product_toViewDetail.getProductID() == 1001){
            img_name = "imgs/broom1Detail.jpg";
        } else if (product_toViewDetail.getProductID() == 1002) {
            img_name = "imgs/broom2Detail.jpg";
        } else if (product_toViewDetail.getProductID() == 1003) {
            img_name = "imgs/broom3Detail.jpg";
        }


        response += "<img src=\""
                + "https://github.com/LeshanZhao/7700Imgs/blob/main/"
                + img_name + "?raw=true"
                + "\" alt=\"image database currently not running, please try again later\"  style=\"width:360px;height:360px;border:3px solid black\">";


        response += "</br> <b style=\"color:green\">" + product_toViewDetail.getQuantityOnHand() + " in stock</b>&emsp;&emsp;&emsp;&emsp;&emsp;";
        response += "<b>$ " + product_toViewDetail.getPrice() + "</b> </br></br>";
        response += "<b>Description:</b> </br>" +
                "<p style=\"color: blue;\">" + product_toViewDetail.getProductDescription() + "</p></br>";
        response += "<b>Comments:</b> <span style=\"color: blue;\">(0)</span></br>";


        String confirm_Number = StoreWebServer.GetConfirmationNumber();
        response += "</br><button onclick=\"myFunction()\">Buy Now</button>";
        response += "<script>\n" +
                "function myFunction() {\n" +
                "   alert('"
                + "Your Order has been submitted. Confirmation number is " + confirm_Number
                + "')" +
                "}\n" +
                "</script>";
        response += "</br></br></br>";

        response = response + "</body></html>";

        return response;
    }
}
